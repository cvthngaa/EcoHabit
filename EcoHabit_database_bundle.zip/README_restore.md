# EcoHabit Database Bundle

Goi nay gom cac file database can mang sang may khac:

- `EcoHabit_db_full.sql`: file SQL day du schema + data duoc export tu PostgreSQL hien tai.
- `seed_data.sql`: seed SQL goc cua project.
- `update-db.js`: script update database dang nam o backend.
- `migrations/`: migration TypeORM source.

## Restore PostgreSQL

1. Cai PostgreSQL tren may moi.
2. Tao database rong:

```powershell
createdb -U postgres -h localhost -p 5432 EcoHabit_db
```

Neu khong co lenh `createdb`, co the tao database bang pgAdmin.

3. Restore file SQL:

```powershell
psql -U postgres -h localhost -p 5432 -d EcoHabit_db -f EcoHabit_db_full.sql
```

Neu khong co lenh `psql`, mo pgAdmin, chon database `EcoHabit_db`, mo Query Tool, dan/noi dung `EcoHabit_db_full.sql` va chay.

4. Cap nhat `backend/.env` tren may moi:

```env
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=<mat-khau-postgres-may-moi>
DB_NAME=EcoHabit_db
```

## Ghi chu

File `EcoHabit_db_full.sql` la file chinh de chuyen du lieu. Cac file `seed_data.sql`, `update-db.js`, va `migrations/` duoc kem theo de doi chieu hoac phat trien tiep.
